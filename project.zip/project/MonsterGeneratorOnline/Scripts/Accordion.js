﻿function accordionFunction(id) {
    var x = document.getElementById(id);
    if (x.className.indexOf("w3-show") == -1) {
        x.className.replace("w3-white", "w3-gray");
        x.className += " w3-show";
    } else {
        x.className.replace("w3-gray", "w3-white");
        x.className = x.className.replace(" w3-show", "");
    }
}