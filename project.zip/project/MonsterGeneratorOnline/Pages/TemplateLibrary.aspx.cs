﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MonsterGeneratorOnline.Pages
{
   public partial class TemplateLibrary : System.Web.UI.Page
   {
      protected void Page_Load(object sender, EventArgs e)
      {
         YourOrderBy.DataSource = Enum.GetNames(typeof(Models.TemplatesSearchOptions));
         YourOrderBy.DataBind();

         CommunityOrderBy.DataSource = Enum.GetNames(typeof(Models.TemplatesCommunitySearchOptions));
         CommunityOrderBy.DataBind();
      }
   }
}