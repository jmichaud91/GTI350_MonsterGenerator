﻿using MonsterGeneratorOnline.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MonsterGeneratorOnline.Pages
{
   public partial class TemplateLibrary : System.Web.UI.Page
   {
      public List<Template> shownTemplates = Models.TemplateLibrary.GetTemplates;
      public List<Template> shownCommunityTemplates = Models.TemplateLibrary.GetTemplates;
      protected void Page_Load(object sender, EventArgs e)
      {
         if (!Page.IsPostBack)
         {
            YourOrderBy.DataSource = Enum.GetNames(typeof(Models.TemplatesSearchOptions));

            CommunityOrderBy.DataSource = Enum.GetNames(typeof(Models.TemplatesCommunitySearchOptions));

            CommunityOrderBy.DataBind();
            YourOrderBy.DataBind();
         }

         YourOrderBy.SelectedIndexChanged += YourOrderBy_SelectedIndexChanged;
         YourFilter.TextChanged += YourFilter_TextChanged;
         CommunityOrderBy.SelectedIndexChanged += CommunityOrderBy_SelectedIndexChanged;
         CommunityFilter.TextChanged += CommunityFilter_TextChanged;
      }

      private void CommunityFilter_TextChanged(object sender, EventArgs e)
      {
         if (CommunityFilter.Text.Length > 0)
         {
            shownCommunityTemplates = Models.TemplateLibrary.Filter(CommunityFilter.Text);
         }
         else
         {
            shownCommunityTemplates = Models.TemplateLibrary.GetTemplates;
         }
      }

      private void CommunityOrderBy_SelectedIndexChanged(object sender, EventArgs e)
      {
         TemplatesCommunitySearchOptions searchValue = TemplatesCommunitySearchOptions.OrderBy;
         if (CommunityOrderBy.SelectedIndex > -1)
         {
            Enum.TryParse(CommunityOrderBy.SelectedValue, out searchValue);

            shownCommunityTemplates = Models.TemplateLibrary.OrderBy(searchValue);
         }
      }

      private void YourFilter_TextChanged(object sender, EventArgs e)
      {
         if (YourFilter.Text.Length > 0)
         {
            shownTemplates = Models.TemplateLibrary.Filter(YourFilter.Text);
         }
         else
         {
            shownTemplates = Models.TemplateLibrary.GetTemplates;
         }
      }

      protected void YourOrderBy_SelectedIndexChanged(object sender, EventArgs e)
      {
         int a = ((DropDownList)sender).SelectedIndex;
         TemplatesSearchOptions searchValue = TemplatesSearchOptions.OrderBy;
         if (YourOrderBy.SelectedIndex > -1)
         {
            Enum.TryParse(YourOrderBy.SelectedValue, out searchValue);
            
            shownTemplates = Models.TemplateLibrary.OrderBy(searchValue);
         }
      }
   }
}