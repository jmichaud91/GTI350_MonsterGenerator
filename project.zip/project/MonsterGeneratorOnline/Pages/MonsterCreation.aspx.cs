﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MonsterGeneratorOnline.Pages
{
   public partial class MonsterCreation : System.Web.UI.Page
   {
      public List<Models.Template> Templates;
      public List<Models.Monsters> Monsters;
      protected void Page_Load(object sender, EventArgs e)
      {
         if (!Page.IsPostBack)
         {
            PrepareTemplates();
            PrepareMonsters();

            GridView_Monsters.DataSource = Monsters;
            GridView_Monsters.DataBind();
            //DataControlField d = new DataGridColumn();
            //GridView_Monsters.Columns.Add()
            //foreach (var monster in Monsters)
            //{

            //}
            //foreach (var item in Monsters)
            //{
            //   ListViewItemType t = ListViewItemType.DataItem;
            //   ListViewItem i = new ListViewItem(t);
            //   i.DataItem = item;
            //   i.
            //}
            //ListView_Monsters.DataSource = Monsters;
            //ListView_Monsters.ItemTemplate = new ListVie
            //ListView_Monsters.DataBind();
         }
      }

      private void PrepareMonsters()
      {
         Monsters = new List<Models.Monsters>();

         Models.Monsters m1 = new Models.Monsters();
         m1.Name = "Beholder";
         m1.Description = "Aggressive, hateful, and greedy, these aberrations dismiss all other creatures as lesser beings, toying with them or destroying them as they choose.";
         m1.Abilities = "Charm ray, Paralyzing ray, fear ray, enervation ray, telekinetic ray, sleep ray, petrification ray, desintegration ray, death ray";
         m1.Type = Models.MonsterTypeRestriction.Aberration;
         m1.Source = "D&D Templates Manual V3.5";
         Monsters.Add(m1);


         Models.Monsters m2 = new Models.Monsters();
         m2.Name = "Mind flayer";
         m2.Description = "Mind flayers, also called illithids, are the scourge of sentient creatures across countless worlds.  Four tentacles snake from their octopus-like heads, flexing in hungry anticipation when thinking creatures come near.";
         m2.Abilities = "Unkown";
         m2.Type = Models.MonsterTypeRestriction.Outsider;
         m2.Source = "D&D Templates Manual V3.5";
         Monsters.Add(m2);

         Models.Monsters m3 = new Models.Monsters();
         m3.Name = "Dragon";
         m3.Description = "True dragons are known and feared for their predatory cunning and their magic, with the oldest dragons accounted as some of the most powerful creatures in the world.";
         m3.Abilities = "Unkown";
         m3.Type = Models.MonsterTypeRestriction.Dragon;
         m3.Source = "D&D Templates Manual V3.5";
         Monsters.Add(m3);

         Models.Monsters m4 = new Models.Monsters();
         m4.Name = "Stone giant";
         m4.Description = "Stone giants are reclusive, quiet and peaceful as long as they are left alone. Their granite-gray skin, gaunt features, and black, sunken eyes endow stone giants with a stern countenance.  They are private creatures, hiding their lives and art away from the world.";
         m4.Abilities = "Unkown";
         m4.Type = Models.MonsterTypeRestriction.Giant;
         m4.Source = "D&D Templates Manual V3.5";
         Monsters.Add(m4);

         Models.Monsters m5 = new Models.Monsters();
         m5.Name = "Beholder";
         m5.Description = "Aggressive, hateful, and greedy, these aberrations dismiss all other creatures as lesser beings, toying with them or destroying them as they choose.";
         m5.Abilities = "Charm ray, Paralyzing ray, fear ray, enervation ray, telekinetic ray, sleep ray, petrification ray, desintegration ray, death ray";
         m5.Type = Models.MonsterTypeRestriction.Aberration;
         m5.Source = "D&D Templates Manual V3.5";
         Monsters.Add(m5);

         Models.Monsters m6 = new Models.Monsters();
         m6.Name = "Kobold";
         m6.Description = "Kobolds are craven reptilian humanoids that worship evil dragons as demigods and serve them as minions and toadies.";
         m6.Abilities = "Unkown";
         m6.Type = Models.MonsterTypeRestriction.Monstrous_Humanoid;
         m6.Source = "D&D Templates Manual V3.5";
         Monsters.Add(m6);

         Models.Monsters m7 = new Models.Monsters();
         m7.Name = "Orc";
         m7.Description = "Orcs are savage raiders and pillagers with stooped postures, low foreheads, and pig-like faces with prominnt lower canines that resemble a boar's tusks.";
         m7.Abilities = "Unkown";
         m7.Type = Models.MonsterTypeRestriction.Humanoid;
         m7.Source = "D&D Templates Manual V3.5";
         Monsters.Add(m7);

         Models.Monsters m8 = new Models.Monsters();
         m8.Name = "Githyanki";
         m8.Description = "Arguably the most skilled navigators of the astral plane, the gaunt, yellow-skinned githyanki are the reavers of a thousand worlds.";
         m8.Abilities = "Unkown";
         m8.Type = Models.MonsterTypeRestriction.Outsider;
         m8.Source = "D&D Templates Manual V3.5";
         Monsters.Add(m8);

      }

      private void PrepareTemplates()
      {
         Templates = new List<Models.Template>();

         Models.Template t1 = new Models.Template();
         t1.Name = "Skeleton";
         t1.Source = "D&D Templates Manual V3.5";
         t1.Description = "Becomes undead.  Keep subtypes that are not based alignment or race. Always neutral evil. Dex + 2, Wis 10, Char 1, CR set by base creature's HD.";
         Templates.Add(t1);


         Models.Template t2 = new Models.Template();
         t2.Name = "Zombie";
         t2.Description = "Becomes undead.  Keep subtypes that are not based on alignment or race.  Always neutral evil.  looses all class levels.  Str +2, Dex -2, Wis 10, Cha 1.  CR set by base creatures's HD.";
         t2.Source = "D&D Templates Manual V3.5";
         Templates.Add(t2);


         Models.Template t3 = new Models.Template();
         t3.Name = "Animus";
         t3.Description = "Becomes undead (augmented, augmented xxx).  Always evil.  HD change to d12's.  Turn resistance +4, DR 10 / magic, Acid resistance 20, Cold resistance 20, Electricity resistance 20, Fast healing 5, Str +4, Char +2, Lvl +4, CR +2.";
         t3.Source = "D&D Templates Manual V3.5";
         Templates.Add(t3);


         Models.Template t4 = new Models.Template();
         t4.Name = "Death knight";
         t4.Description = "Becomes undead.  Natural armor bonusS +5 (if better than base creature). DR 15 / magic, SR 20 + 1 per level above 10th.  Str +4, Wis +2, Cha +2, CR +3.";
         t4.Source = "D&D Templates Manual V3.5";
         Templates.Add(t4);


         Models.Template t5 = new Models.Template();
         t5.Name = "Living wall";
         t5.Description = "Become undead (augmented xxx).  Becomes medium-size.  Keeps its original reach, but looses all other size-based bonuses.  Always evil.  Natural armor bonus is +5 or the base creature's natural armor bonus (the higher).  +4 racial bonus to listen & spot checks.  DR 5 / --, All movement becomes 0.  Str +4, Cha +4, CR +1.";
         t5.Source = "D&D Templates Manual V3.5";
         Templates.Add(t5);


         Models.Template t6 = new Models.Template();
         t6.Name = "Vamprism";
         t6.Description = "Allow the user to see in the dark and steal health point on successful attack.";
         t6.Source = "D&D Templates Manual V3.5";
         Templates.Add(t6);


         Models.Template t7 = new Models.Template();
         t7.Name = "Half-golem - Dragonflesh";
         t7.Description = "Natural armor bonus +7, DR 10/ adamantine, Str +6, Dex -2, Int -6, Con +4 (or N/A), Cha -6, CR +3.";
         t7.Source = "D&D Templates Manual V3.5";
         Templates.Add(t7);


         Models.Template t8 = new Models.Template();
         t8.Name = "Voidmind";
         t8.Description = "Creature type is unchanged.  +4 improvement to natural armor.  Darkvision 60'.  Spell resistance of 10+ HD.  Usually lawful evil.  Gains the following feats : Alertness, combat reflexes and great fortitude.  +4 racial bonus on Bluff, Escape artist & intimidate checks.  Str +4, Dex +2, Con +2, Int +2, Cha -2, Lvl +1, CR +3.";
         t8.Source = "D&D Templates Manual V3.5";
         Templates.Add(t8);
      }

      protected void lbNoneScenarios_Click(object sender, EventArgs e)
      {

      }

      protected void lbAllScenarios_Click(object sender, EventArgs e)
      {

      }
   }
}