﻿using MonsterGeneratorOnline.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MonsterGeneratorOnline.Pages
{
   public partial class MonsterCreation : System.Web.UI.Page
   {
      public List<Models.Template> Templates = Models.TemplateLibrary.GetTemplates;
      public List<Models.Monsters> Monsters = Models.MonsterLibary.GetMonsters;
      public List<Models.RestrictedScenario> Scenarios = Models.RestrictedScenarioLibrary.GetScenarios;

      protected void Page_Load(object sender, EventArgs e)
      {
         bool eventsWereHooked = false;
         if (!Page.IsPostBack)
         {
            GridView_Monsters.DataSource = Monsters;
            GridView_Monsters.DataBind();

            GridView_Templates.DataSource = Templates;
            GridView_Templates.DataBind();

            GridView_RestrictedScenarios.DataSource = Scenarios;
            GridView_RestrictedScenarios.DataBind();

            selectedMonster = null;
            selectedtemplates = null;
            GridView_Monsters.SelectRow(-1);
            GridView_Templates.SelectRow(-1);
            GridView_RestrictedScenarios.SelectRow(-1);

            string item = Request.QueryString["item"];
            if (item != null)
            {
               GridView_Templates.SelectedIndexChanged += GridView_Templates_SelectedIndexChanged2;
               Button_Cancel.Click += Button_Cancel_Click;
               Button_Save.Click += Button_Save_Click;
               eventsWereHooked = true;

               Monsters m = Models.MonsterLibary.GetMonsters.Find(x => x.Name == item);
               SelectMonster(m.Name);
               SelectTemplate(m.AppliedTemplate);
               SelectScenario(m);
            }
         }

         if (!eventsWereHooked)
         {
            GridView_Templates.SelectedIndexChanged += GridView_Templates_SelectedIndexChanged2;
            Button_Cancel.Click += Button_Cancel_Click;
            Button_Save.Click += Button_Save_Click;
         }
      }

      private void SelectMonster(string name)
      {
         int selectedIndex = 0;
         int curIndex = 0;

         foreach (Monsters m in Monsters)
         {
            if (name.ToLower().Contains(m.Name.ToLower()))
            {
               selectedIndex = curIndex;
               break;
            }

            curIndex++;
         }

         GridView_Monsters.SelectRow(selectedIndex);
      }

      private void SelectTemplate(Template t)
      {
         if (t != null)
         {
            GridView_Templates.SelectedIndex = -1;
            int selectedIndex = 0;
            int curIndex = 0;

            foreach (Template te in Templates)
            {
               if (t.Name.ToLower().Contains(te.Name.ToLower()))
               {
                  selectedIndex = curIndex;
                  break;
               }

               curIndex++;
            }

            GridView_Templates.SelectRow(selectedIndex);
         }
         else
         {
            GridView_Templates.SelectedIndex = -1;
         }
      }

      private void SelectScenario(Monsters m)
      {
         if (m != null)
         {
            int selectedIndex = 0;
            int curIndex = 0;

            foreach (RestrictedScenario rs in Scenarios)
            {
               if (m.Scenario.ToLower().Contains(rs.Scenario.ToLower()))
               {
                  selectedIndex = curIndex;
                  break;
               }

               curIndex++;
            }

            GridView_RestrictedScenarios.SelectRow(selectedIndex);
         }
      }

      private static Monsters newMonster;
      private void Button_Save_Click(object sender, EventArgs e)
      {
         string confirmValue = Request.Form["confirm_value"];
         if (confirmValue == "Yes")
         {
            if (selectedMonster != null)
            {
               Random rnd = new Random();

               if (newMonster.AppliedTemplate != null)
               {
                  newMonster.Name += string.Format(" ({0})", newMonster.AppliedTemplate.Name);
               }

               Models.MonsterLibary.GetMonsters.Add(newMonster);

               string script = "alert(\"Monster creation successful ! You can now access it from the bestiary !\");";
               ScriptManager.RegisterStartupScript(this, GetType(),
                                     "ServerControlScript", script, true);

               Response.Redirect("~");
            }
         }
      }

      private void Button_Cancel_Click(object sender, EventArgs e)
      {
         string confirmValue = Request.Form["confirm_value"];
         if (confirmValue == "Yes")
         {
            Response.Redirect("~");
         }
      }

      private void GridView_Templates_SelectedIndexChanged2(object sender, EventArgs e)
      {
         if (GridView_Templates.SelectedIndex >= 0)
         {
            selectedtemplates = Templates[GridView_Templates.SelectedIndex];
            if (newMonster != null)
            {
               newMonster.AppliedTemplate = selectedtemplates;
            }
         }
      }

      protected void lbNoneScenarios_Click(object sender, EventArgs e)
      {

      }

      protected void lbAllScenarios_Click(object sender, EventArgs e)
      {

      }

      public static Models.Monsters selectedMonster = null;
      public static Models.Template selectedtemplates = null;
      protected void GridView_Monsters_SelectedIndexChanged(object sender, EventArgs e)
      {
         if (GridView_Monsters.SelectedIndex >= 0)
         {
            selectedMonster = Monsters[GridView_Monsters.SelectedIndex];
            Random rnd = new Random();
            newMonster = new Models.Monsters
            {
               Abilities = selectedMonster.Abilities,
               ArmorClass = selectedMonster.ArmorClass,
               AppliedTemplate = selectedMonster.AppliedTemplate,
               Attack = selectedMonster.Attack,
               BaseAttack = selectedMonster.BaseAttack,
               Cha = selectedMonster.Cha,
               Const = selectedMonster.Const,
               Description = selectedMonster.Description,
               Dex = selectedMonster.Dex,
               Fortitude = selectedMonster.Fortitude,
               FullAttack = selectedMonster.FullAttack,
               Grapple = selectedMonster.Grapple,
               Hitdice = selectedMonster.Hitdice,
               Initiative = selectedMonster.Initiative,
               Int = selectedMonster.Int,
               LevelAdjustment = selectedMonster.LevelAdjustment,
               Name = selectedMonster.Name,
               Rating = rnd.Next(80, 100),
               Reach = selectedMonster.Reach,
               Reflexe = selectedMonster.Reflexe,
               Scenario = selectedMonster.Scenario,
               Source = "USER CREATION",
               Space = selectedMonster.Space,
               SpecialAttacks = selectedMonster.SpecialAttacks,
               Speed = selectedMonster.Speed,
               Str = selectedMonster.Str,
               Type = selectedMonster.Type,
               Will = selectedMonster.Will,
               Wis = selectedMonster.Wis
            };

            if (selectedtemplates != null)
            {
               newMonster.AppliedTemplate = selectedtemplates;
            }
         }
      }

      protected void GridView_Templates_SelectedIndexChanged(object sender, EventArgs e)
      {

      }

      protected void GridView_Templates_SelectedIndexChanged1(object sender, EventArgs e)
      {

      }
   }
}