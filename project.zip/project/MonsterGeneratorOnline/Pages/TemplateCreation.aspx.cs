﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MonsterGeneratorOnline.Controls;

namespace MonsterGeneratorOnline.Pages
{
   public partial class TemplateCreation : System.Web.UI.Page
   {
      private static int statCount = 1;
      private static int abilityCount = 1;
      private static List<Control> stats;
      private static List<Control> abilities;
      protected void Page_Load(object sender, EventArgs e)
      {
         if (!Page.IsPostBack)
         {
            stats = new List<Control>();
            abilities = new List<Control>();
            statCount = 1;
            abilityCount = 1;
         }
      }

      protected void lbAll_Click(object sender, EventArgs e)
      {
         //foreach (ListItem item in List_RestScenarios.Items)
         //{
         //   item.Selected = true;
         //}
      }

      protected void lbNone_Click(object sender, EventArgs e)
      {

         //foreach (ListItem item in List_RestScenarios.Items)
         //{
         //   item.Selected = false;
         //}
      }

      protected void lbNoneTypes_Click(object sender, EventArgs e)
      {

      }

      protected void lbAllTypes_Click(object sender, EventArgs e)
      {

      }
      
      protected void buttonAddStats_Click(object sender, EventArgs e)
      {
         statCount++;
         
         AddControls();

         StatisticControl c = (StatisticControl)Page.LoadControl("~/Controls/StatisticControl.ascx");
         c.ID = string.Format("statControl_{0}", statCount);

         StatContainer.Controls.Add(c);
         StatContainer.Controls.Add(new LiteralControl("<br />"));
         StatContainer.DataBind();
         stats.Add(c);
      }

      private void AddControls()
      {
         foreach (var item in stats)
         {
            StatContainer.Controls.Add(item);
            StatContainer.Controls.Add(new LiteralControl("<br />"));
            StatContainer.DataBind();
         }

         foreach (var item in abilities)
         {
            AbilityContainer.Controls.Add(item);
            AbilityContainer.Controls.Add(new LiteralControl("<br />"));
            AbilityContainer.DataBind();
         }
      }

      protected void buttonAddAbilities_Click(object sender, EventArgs e)
      {
         abilityCount++;

         AddControls();

         AbilityControl c = (AbilityControl)Page.LoadControl("~/Controls/AbilityControl.ascx");
         c.ID = string.Format("abilityControl_{0}", abilityCount);

         AbilityContainer.Controls.Add(c);
         AbilityContainer.Controls.Add(new LiteralControl("<br />"));
         AbilityContainer.DataBind();
         abilities.Add(c);
      }
   }
}