﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MonsterGeneratorOnline.Controls;
using MonsterGeneratorOnline.Models;

namespace MonsterGeneratorOnline.Pages
{
   public partial class TemplateCreation : System.Web.UI.Page
   {
      private static int statCount = 1;
      private static int abilityCount = 1;

      private static List<Control> stats;
      private static List<Control> abilities;

      public static List<Monsters> ShownMonsters = Models.MonsterLibary.GetMonsters;
      public static List<RestrictedScenario> ShownScenarios = Models.RestrictedScenarioLibrary.GetScenarios;
      protected void Page_Load(object sender, EventArgs e)
      {
         if (!Page.IsPostBack)
         {
            stats = new List<Control>();
            abilities = new List<Control>();
            statCount = 1;
            abilityCount = 1;

            Gridview_RestrictedScenario.DataSource = ShownScenarios;
            Gridview_RestrictedScenario.DataBind();

            GridView_RestrictedTypes.DataSource = ShownMonsters;
            GridView_RestrictedTypes.DataBind();
         }

         string item = Request.QueryString["item"];
         if (item != null)
         {
            Template t = Models.TemplateLibrary.GetTemplates.Find(x => x.Name == item);
            Textbox_Name.Text = t.Name;
            Textbox_Desc.Text = t.Description;

            ShowStatistic(t);
            ShowAbilities(t);
         }

         Button_Cancel.Click += Button_Cancel_Click;
         Button_Save.Click += Button_Save_Click;
      }

      private void ShowStatistic(Template t)
      {
         foreach (var stat in t.Statistic)
         {
            foreach (Control co in StatContainer.Controls)
            {
               if (co.ID == "statControl" + statCount.ToString())
               {
                  co.Visible = true;
                  ((MonsterGeneratorOnline.Controls.StatisticControl)co).name = stat.ModifiedStatistic;
                  ((MonsterGeneratorOnline.Controls.StatisticControl)co).value = stat.Value.ToString();
               }
            }

            statCount++;
         }
      }

      private void ShowAbilities(Template t)
      {
         foreach (var ability in t.Abilities)
         {
            foreach (Control co in AbilityContainer.Controls)
            {
               if (co.ID == "abilityControl" + abilityCount.ToString())
               {
                  co.Visible = true;
                  ((MonsterGeneratorOnline.Controls.AbilityControl)co).Name = ability.AbilityName;
                  ((MonsterGeneratorOnline.Controls.AbilityControl)co).Level = ability.Level.ToString();
               }
            }

            abilityCount++;
         }
      }

      private void Button_Save_Click(object sender, EventArgs e)
      {
         string confirmValue = Request.Form["confirm_value"];
         if (confirmValue == "Yes")
         {
            Template newTemplate = new Template();
            newTemplate.Name = Textbox_Name.Text;
            newTemplate.Description = Textbox_Desc.Text;
            if (GridView_RestrictedTypes.SelectedIndex > -1)
            {
               newTemplate.RestrictedTypes = ShownMonsters[GridView_RestrictedTypes.SelectedIndex].Type;
            }
            newTemplate.Source = "HOME MADE CREATION";

            foreach (var stat in StatContainer.Controls)
            {
               if (stat.GetType().Name.ToLower() == "controls_statisticcontrol_ascx")
               {
                  StatisticControl c = (StatisticControl)stat;
                  if (c.Visible)
                  {

                     int numberOfDices = 1;
                     int face = 4;
                     int flatValue = 0;
                     string statName = "";

                     foreach (Control co in c.Controls)
                     {
                        if (co.ID == "DDL_StatName")
                        {
                           statName = ((DropDownList)co).Text;
                        }
                        else if (co.ID == "TextBox_Dices")
                        {
                           numberOfDices = Convert.ToInt32(((TextBox)co).Text);
                        }
                        else if (co.ID == "DDL_Dice")
                        {
                           face = Convert.ToInt32(((DropDownList)co).Text);
                        }
                        else if (co.ID == "Textbox_Flat")
                        {
                           flatValue = Convert.ToInt32(((TextBox)co).Text);
                        }
                     }

                     Statistic newStat = new Statistic
                     {
                        ModifiedStatistic = statName,
                        Value = ((numberOfDices * face) / 2) + flatValue
                     };

                     newTemplate.Statistic.Add(newStat);
                  }
               }
            }

            foreach (var stat in AbilityContainer.Controls)
            {
               if (stat.GetType().Name == "controls_abilitycontrol_ascx")
               {
                  AbilityControl c = (AbilityControl)stat;
                  if (c.Visible)
                  {

                     int level = 1;
                     string abilityName = "";

                     foreach (Control co in c.Controls)
                     {
                        if (co.ID == "DLL_AbilityName")
                        {
                           abilityName = ((DropDownList)co).Text;
                        }
                        else if (co.ID == "TextBox_Level")
                        {
                           level = Convert.ToInt32(((TextBox)co).Text);
                        }
                     }

                     Ability newAbility = new Ability
                     {
                        AbilityName = abilityName,
                        Level = level
                     };

                     newTemplate.Abilities.Add(newAbility);
                  }
               }
            }

            Models.TemplateLibrary.GetTemplates.Add(newTemplate);
            Response.Redirect("~");
         }
      }

      private void Button_Cancel_Click(object sender, EventArgs e)
      {
         string confirmValue = Request.Form["confirm_value"];
         if (confirmValue == "Yes")
         {
            Response.Redirect("~");
         }
      }

      protected void lbAll_Click(object sender, EventArgs e)
      {
         //foreach (ListItem item in List_RestScenarios.Items)
         //{
         //   item.Selected = true;
         //}
      }

      protected void lbNone_Click(object sender, EventArgs e)
      {

         //foreach (ListItem item in List_RestScenarios.Items)
         //{
         //   item.Selected = false;
         //}
      }

      protected void lbNoneTypes_Click(object sender, EventArgs e)
      {

      }

      protected void lbAllTypes_Click(object sender, EventArgs e)
      {

      }

      protected void buttonAddStats_Click(object sender, EventArgs e)
      {
         statCount++;

         foreach (Control co in StatContainer.Controls)
         {
            if (co.ID == "statControl" + statCount.ToString())
            {
               co.Visible = true;
            }
         }
      }

      protected void buttonAddAbilities_Click(object sender, EventArgs e)
      {
         abilityCount++;

         foreach (Control co in AbilityContainer.Controls)
         {
            if (co.ID == "abilityControl" + abilityCount.ToString())
            {
               co.Visible = true;
            }
         }
      }
   }
}