﻿using MonsterGeneratorOnline.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MonsterGeneratorOnline.Pages
{
   public partial class Bestiary : System.Web.UI.Page
   {
      public List<Monsters> shownMonsters = MonsterLibary.GetMonsters;
      public List<Monsters> shownCommunityMonsters = MonsterLibary.GetMonsters;
      protected void Page_Load(object sender, EventArgs e)
      {
         if (!Page.IsPostBack)
         {
            YourOrderBy.DataSource = Enum.GetNames(typeof(Models.BestiarySearchOptions));
            YourOrderBy.DataBind();

            CommunityOrderBy.DataSource = Enum.GetNames(typeof(Models.BestiaryCommunitySearchOptions));
            CommunityOrderBy.DataBind();
         }

         YourFilter.TextChanged += YourFilter_TextChanged;
         YourOrderBy.SelectedIndexChanged += YourOrderBy_SelectedIndexChanged;

         CommunityFilter.TextChanged += CommunityFilter_TextChanged;
         CommunityOrderBy.SelectedIndexChanged += CommunityOrderBy_SelectedIndexChanged;
      }

      private void CommunityOrderBy_SelectedIndexChanged(object sender, EventArgs e)
      {
         BestiaryCommunitySearchOptions searchValue = BestiaryCommunitySearchOptions.OrderBy;
         if (CommunityOrderBy.SelectedIndex > -1)
         {
            Enum.TryParse(CommunityOrderBy.SelectedValue, out searchValue);

            shownCommunityMonsters = Models.MonsterLibary.OrderBy(searchValue);
         }
      }

      private void CommunityFilter_TextChanged(object sender, EventArgs e)
      {
         if (CommunityFilter.Text.Length > 0)
         {
            shownCommunityMonsters = Models.MonsterLibary.Filter(CommunityFilter.Text);
         }
         else
         {
            shownCommunityMonsters = Models.MonsterLibary.GetMonsters;
         }
      }

      private void YourOrderBy_SelectedIndexChanged(object sender, EventArgs e)
      {
          BestiarySearchOptions searchValue = BestiarySearchOptions.OrderBy;
         if (YourOrderBy.SelectedIndex > -1)
         {
            Enum.TryParse(YourOrderBy.SelectedValue, out searchValue);

            shownMonsters = Models.MonsterLibary.OrderBy(searchValue);
         }
      }

      private void YourFilter_TextChanged(object sender, EventArgs e)
      {
         if (YourFilter.Text.Length > 0)
         {
            shownMonsters = Models.MonsterLibary.Filter(YourFilter.Text);
         }
         else
         {
            shownMonsters = Models.MonsterLibary.GetMonsters;
         }
      }
   }
}