﻿using System.Web.UI;

namespace MonsterGeneratorOnline.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}