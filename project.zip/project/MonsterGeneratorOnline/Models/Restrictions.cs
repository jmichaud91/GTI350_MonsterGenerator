﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MonsterGeneratorOnline.Models
{
   public enum ScenariosRestriction {
        Dungeon,
        Tower,
        Catedral,
        Bridge,
        Prison,
        Castle,
        Sewer,
        Forest,
        Swamp,
        Desert,
        Underworld,
        Heaven
   }

   public enum MonsterTypeRestriction
   {
      Aberration,
      Animal,
      Beast,
      Construct,
      Deathless,
      Dragon,
      Elemental,
      Fey,
      Giant,
      Humanoid,
      Magical_Beast,
      Monstrous_Humanoid,
      Ooze,
      Outsider,
      Planetouched,
      Plant,
      Shapechanger,
      Undead,
      Vermin
   }
}