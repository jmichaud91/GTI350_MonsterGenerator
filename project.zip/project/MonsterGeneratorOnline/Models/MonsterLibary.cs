﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MonsterGeneratorOnline.Models
{
   public class MonsterLibary
   {
      public static List<Monsters> OriginalMonsters;
      public static List<Monsters> GetMonsters
      {
         get
         {
            if (OriginalMonsters == null)
            {
               OriginalMonsters = new List<Monsters>();
               ConstructOriginalMonsters();
            }

            

            return OriginalMonsters;
         }
      }

      private static string[] MonsterTypes = new string[]
      {
         "Aberration", "Outsider", "Outsider", "Aberration", "Monstrous humanoid",
         "Outsider", "Animal", "Animal", "Dragon", "Magical beast", "Giant", "Humanoid",
         "Construct", "Magical beast", "Monstrous humanoid", "Outsider",
         "Magical beast", "Magical beast", "Outsider", "Undead"
      };
      
      private static string[] RestrictedScenarios = new string[]
      {
         "Hills",
         "Underworld",
         "Heaven",
         "Forest",
         "Forest",
         "Underworld",
         "Forest",
         "Forest",
         "Hills",
         "Hills",
         "Hills",
         "Desert",
         "Prison",
         "Forest",
         "Forest",
         "Forest",
         "Hills",
         "Underworld",
         "Underworld",
         "Underworld"
      };

      private static string[] MonsterNames = new string[]
      {
         "Beholder", "Bebilth", "Archon", "Chuul", "Centaur", "Succubus", "Deinonychus",
         "Dire wolf", "Red dragon", "Dragonne", "Cloud giant", "Githzerai",
         "Flesh golem", "Gray render", "Grimlock", "Leonal", "Pyrohydra", "Kraken",
         "Mind flayer", "Nightcrawler"
      };


      private static List<int>[] Statistics = new List<int>[]
      {
         new List<int> { 88,   6,  5, 26, 8,  12, 4, 4, 10, 5, 9, 5, 11, 10,  14, 18, 17, 15, 15, 0 },
         new List<int> { 50,   7,  6, 20, 6,  14, 6, 6, 12, 4, 7, 7, 12, 8,   12, 15, 21, 21, 11, 2 },
         new List<int> { 52,   8,  5, 22, 6,  12, 5, 6, 11, 4, 7, 7, 13, 9,   13, 14, 20, 22, 12, 1 },
         new List<int> { 82,   5,  6, 27, 7,  13, 5, 6, 10, 3, 7, 7, 15, 11,  12, 16, 18, 15, 16, 2 },
         new List<int> { 128,  6,  7, 18, 10, 12, 4, 6, 14, 5, 7, 7, 12, 12,  12, 18, 15, 16, 17, 2 },
         new List<int> { 24,   6,  6, 24, 9,  14, 8, 5, 10, 4, 6, 7, 11, 8,   11, 20, 16, 14, 15, 1 },
         new List<int> { 72,   7,  6, 32, 8,  11, 8, 6, 12, 4, 6, 7, 11, 9,   9,  18, 12, 13, 14, 2 },
         new List<int> { 70,   8,  4, 24, 9,  12, 8, 6, 12, 4, 7, 7, 13, 8,   12, 19, 14, 21, 12, 2 },
         new List<int> { 100,  9,  5, 18, 11, 12, 8, 7, 13, 4, 8, 7, 12, 8,   12, 12, 20, 22, 15, 3 },
         new List<int> { 82,   10, 5, 19, 5,  11, 8, 7, 11, 4, 8, 7, 12, 6,   13, 14, 22, 15, 16, 3 },
         new List<int> { 42,   5,  8, 21, 6,  12, 8, 8, 15, 4, 4, 7, 13, 6,   13, 15, 18, 12, 19, 1 },
         new List<int> { 86,   6,  7, 25, 7,  11, 8, 4, 14, 4, 5, 7, 11, 7,   15, 13, 19, 13, 18, 1 },
         new List<int> { 88,   7,  7, 24, 8,  11, 8, 4, 13, 4, 5, 7, 12, 8,   12, 13, 21, 17, 12, 0 },
         new List<int> { 92,   9,  7, 21, 11, 10, 8, 5, 11, 4, 6, 7, 10, 9,   11, 12, 22, 20, 11, 0 },
         new List<int> { 94,   11, 6, 20, 10, 10, 8, 5, 11, 4, 7, 7, 10, 10,  10, 16, 15, 25, 11, 1 },
         new List<int> { 76,   10, 5, 19, 8,  14, 8, 6, 10, 4, 8, 7, 12, 15,  11, 20, 16, 19, 13, 2 },
         new List<int> { 50,   8,  6, 17, 6,  12, 8, 7, 15, 4, 9, 7, 11, 12,  10, 21, 17, 15, 15, 2 },
         new List<int> { 56,   7,  4, 20, 7,  12, 8, 5, 16, 4, 9, 7, 12, 11,  15, 16, 21, 17, 14, 3 },
         new List<int> { 48,   6,  6, 23, 7,  11, 8, 4, 12, 4, 8, 7, 13, 8,   16, 18, 20, 18, 11, 2 },
         new List<int> { 42,   5,  5, 25, 6,  11, 8, 8, 8,  4, 7, 7, 15, 9,   14, 19, 25, 21, 12, 2 },
      };

      private static List<string> Skills = new List<string>
      {
         "Hide +12, Knowledge +17, Listen +18, Search +21, Spot +22, Survival +2",
         "Hunt +8, Listen +21, Survival +14, Spot +12",
         "Hide +2, Knowledge + 21, Spot evil +24",
         "Hunt +16, Listen +20, Survival +16, Spot +14",
         "Hide +16, Knowledge +15, Listen +19, Spot +32, Survival +4",
         "Hide +20, knowledge +20, Listen +14, Search +20",
         "Knowledge +8, Listen +21, Search +21, Spot +24, Survival +8",
         "Hunt +9, Listen +12, Survival +8",
         "Knowledge +20, Listen +2, Spot +24, Survival +6, Thoughness +14",
         "Hide +2, Knowledge +12, Listen +21, Thoughness +20",
         "Hide +14, Knowledge +24, Listen +18, Search +22, Spot +22, Survival +4",
         "Knowledge +20, Listen +2, Spot +24, Survival +6, Thoughness +14",
         "Hide +16, Knowledge +15, Listen +19, Spot +32, Survival +4",
         "Hide +12, Knowledge +17, Listen +18, Search +21, Spot +22, Survival +2",
         "Hunt +9, Listen +12, Survival +8",
         "Hide +16, Knowledge +15, Listen +19, Spot +32, Survival +4",
         "Knowledge +8, Listen +21, Search +21, Spot +24, Survival +8",
         "Hunt +16, Listen +20, Survival +16, Spot +14",
         "Hunt +9, Listen +12, Survival +8",
         "Hunt +16, Listen +20, Survival +16, Spot +14",
      };

      private static List<string> SpecialAttacks = new List<string>
      {
         "Eye rays",
         "Ravage, Smell blood",
         "Smite evil, Clean evil",
         "Ravage, Claw, Rip",
         "Snipe, quite shot, multiple shot",
         "Seduce, Ravage",
         "Ravage, smell blood, rip, run",
         "Ravage",
         "Fire breath, Fire cone, Fire wings, Fly, Devour",
         "Devour, Fly, Ravage, Smell blood",
         "None",
         "None",
         "Smash, Regeneration",
         "ravage, smell blood, rip",
         "none",
         "none",
         "Fire breath, regeneration",
         "Tantacle, grip, crush",
         "Read mind, Mind control, Energy drain, Tantacle",
         "Ravage, drain"
      };

      private static string[] MosnterDescriptions = new string[]
      {
         "A beholder is an 8-foot-wide orb dominated by a central eye and a large, toothy maw.  Ten smaller eyes on stalks sprout from the top of the orb.",
         "Bebilths are enormous, predatory, arachnid deamons that hunt other deamons.  While they favor preying upon other demons, they aren't picky - They will stalk and attack any type of creature.",
         "Archons are celestials from the plane of Celestia.  They have charged themselves with the protection of the plane, and also consider themselves guardians of all who are innocent or free of evil.",
         "A horrible mix of crustacean, insect, and serpent, the chuul is an abomination that lurks submerged or partially submerged, awaiting intelligent prey to devour.",
         "Centaurs are woodland beings who shun the company of strangers.  They are deadly archers and even more fearsome in melee.  A centaur is a big as heavy horse, but much taller and slightly heavier.  A centaur is about 7 feet tall and weights about 2,100 pounds. Centaurs speak Sylvan and Elven.",
         "Succubi are the most comely of the tanar'ri (perhaps of all demons), and they live to tempt mortals.  A succubus is 6 feet tall in its natural form and weights about 125 pounds.",
         "This fast carnivore is sometimes called a velociraptor, though that name properly belongs to a much smaller creature.",
         "Dire wolves prefer to attack in packs, surrounding and flanking a foe when they can.",
         "Red dragons are the most covetous of all dragons, forever seeking to increase their treasure hoards.  They are exceptionnaly vain, which is reflected in their proud bearing and disdainful expression.",
         "Possessing some of the most dangerous qualities of a lion and a brass dragon, the dragonne is a vicious and deadly hunter.",
         "Cloud giants consider themselves above all others, except storm giants, whom they regard as equals.  They are creative, appreciate fine things, and are master strategist in battle.",
         "Githzerai are a hard-hearted, humanlike people who dwell on the plane of Limbo, secure in the protection of their hidden monasteries.",
         "A flesh golem is a ghoulish collection of stolen humanoid body parts, stitched toguether into a single composite form.",
         "Bestial and savage, the gray render is a deadly predator found in remote wilderness areas.",
         "Grimlocks are natives of the deep places beneath the earth but come to the surface to raid for slaves and pillage.",
         "One of the most powerful guardinal forms, a leonal is every bit as regal as a lion of the Material plane.  As a foe, it can be just as terrifying, bellowing mighty roars and slahing with razor-sharp claws.",
         "These reddish hydras can breathe jets of fire 10 feet high, 10 feet wide, and 20 feet long.  All heads breathe once every 1d4 rounds.",
         "Aggressive, crual, and highly intelligent, krakens rule entire undersea regions.  Though these behemoths are rearely seen on the surface, stories tell of ships dragged under and islands scoured of life by these monsters.",
         "Mind flayers, also called illithids, are so insidious, diabolical, and powerful that all denizens of the dark fear them.  They bend others to their will and shatter enemies' minds.",
         "A nightcrawler is a massive behemoth similar to a purple worm, though utterly black in color."
      };

      private static void ConstructOriginalMonsters()
      {
         Random rnd = new Random();
         for (int i = 0; i < MonsterNames.Length; i++)
         {
            Monsters m = new Monsters();
            m.Name = MonsterNames[i];
            m.Type = MonsterTypes[i];
            m.Description = MosnterDescriptions[i];
            m.Rating = rnd.Next(80, 100);

            m.Hitdice = Statistics[i][0];
            m.Initiative = Statistics[i][1];
            m.Speed = Statistics[i][2];
            m.ArmorClass = Statistics[i][3];
            m.BaseAttack = Statistics[i][4];
            m.Grapple = Statistics[i][5];
            m.Attack = Statistics[i][6];
            m.FullAttack = Statistics[i][7];
            m.Space = Statistics[i][8];
            m.Reach = Statistics[i][9];
            m.Fortitude = Statistics[i][10];
            m.Reflexe = Statistics[i][11];
            m.Will = Statistics[i][12];
            m.Str = Statistics[i][13];
            m.Dex = Statistics[i][14];
            m.Const = Statistics[i][15];
            m.Int = Statistics[i][16];
            m.Wis = Statistics[i][17];
            m.Cha = Statistics[i][18];
            m.LevelAdjustment = Statistics[i][19];

            m.Abilities = Skills[i];
            m.Source = "D&D Monster manual 3.5";
            m.SpecialAttacks = SpecialAttacks[i];
            m.Scenario = RestrictedScenarios[i];

            OriginalMonsters.Add(m);
         }
      }

      public static List<Monsters> Filter(string filter)
      {
         List<Monsters> filteredList = new List<Monsters>();

         filteredList = OriginalMonsters.FindAll(x => x.Name.ToLower().Contains(filter.ToLower()));

         return filteredList;
      }

      public static List<Monsters> OrderBy(BestiaryCommunitySearchOptions searchOprion)
      {
         List<Monsters> orderedList = new List<Monsters>();
         switch (searchOprion)
         {
            case BestiaryCommunitySearchOptions.OrderBy:
               orderedList = OriginalMonsters;
               break;
            case BestiaryCommunitySearchOptions.Name:
               orderedList = OriginalMonsters.OrderBy(x => x.Name).ToList();
               break;
            case BestiaryCommunitySearchOptions.Scenario:
               orderedList = OriginalMonsters;
               break;
            case BestiaryCommunitySearchOptions.Type:
               orderedList = OriginalMonsters.OrderBy(x => x.Type).ToList();
               break;
            case BestiaryCommunitySearchOptions.Rating:
               orderedList = OriginalMonsters.OrderByDescending(x => x.Rating).ToList();
               break;
            default:
               orderedList = OriginalMonsters;
               break;
         }

         return orderedList;
      }

      public static List<Monsters> OrderBy(BestiarySearchOptions searchOprion)
      {
         List<Monsters> orderedList = new List<Monsters>();
         switch (searchOprion)
         {
            case BestiarySearchOptions.OrderBy:
               orderedList = OriginalMonsters;
               break;
            case BestiarySearchOptions.Name:
               orderedList = OriginalMonsters.OrderBy(x => x.Name).ToList();
               break;
            case BestiarySearchOptions.Scenario:
               orderedList = OriginalMonsters;
               break;
            case BestiarySearchOptions.Type:
               orderedList = OriginalMonsters.OrderBy(x => x.Type).ToList();
               break;
            default:
               orderedList = OriginalMonsters;
               break;
         }

         return orderedList;
      }
   }
}