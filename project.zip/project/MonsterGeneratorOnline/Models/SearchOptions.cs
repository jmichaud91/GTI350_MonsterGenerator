﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MonsterGeneratorOnline.Models
{
   public enum BestiarySearchOptions
   {
      OrderBy = 0,
      Name = 1,
      Scenario = 2,
      Type = 3
   }

   public enum BestiaryCommunitySearchOptions
   {
      OrderBy = 0,
      Name = 1,
      Scenario = 2,
      Type = 3,
      Rating = 4
   }

   public enum TemplatesSearchOptions
   {
      OrderBy = 0,
      Name = 1,
      Restriction = 2
   }

   public enum TemplatesCommunitySearchOptions
   {
      OrderBy = 0,
      Name = 1,
      Restriction = 2,
      Rating = 3
   }
}