﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MonsterGeneratorOnline.Models
{
   public class Dices
   {
      public static int[] DiceFaces = { 4, 6, 8, 10, 12, 16, 20 };
   }
}