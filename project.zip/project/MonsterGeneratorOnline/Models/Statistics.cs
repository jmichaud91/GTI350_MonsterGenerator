﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MonsterGeneratorOnline.Models
{
   public class Statistics
   {
      public static string[] StatNames = { "Hit Dice", "Initiative", "Speed", "Armor Class", "Base Attack", "Grapple", "Attack", "Full attack", "Space", "Reach", "Special Attacks", "Fortitude", "Reflexe", "Will", "Strenght", "Dexterity", "Consitution", "Intelligence", "Wisdom", "Charisma", "Level Adjustment" };
   }
}