﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MonsterGeneratorOnline.Models
{
   public class Statistics
   {
      public enum StatNames
      {
         HealthPoint,
         Energy,
         Damage,
         Constitution,
         Spirit,
         Magic,
         Endurance
      }
   }
}