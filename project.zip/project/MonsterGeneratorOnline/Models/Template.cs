﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MonsterGeneratorOnline.Models
{
   public class Template
   {
      public string Name { get; set; }
      public string Description { get; set; }
      public string Source { get; set;}
      public double Rating { get; set; }
      public string RestrictedTypes { get; set; }
      public List<Statistic> Statistic { get; set; }
      public List<Ability> Abilities { get; set; }

      public Template()
      {
         Statistic = new List<Models.Statistic>();
         Abilities = new List<Models.Ability>();
      }
   }

   public class Ability
   {
      public string AbilityName { get; set; }
      public int Level { get; set; }
   }

   public class Statistic
   {
      public string ModifiedStatistic { get; set; }
      public int Value { get; set; }
   }
}