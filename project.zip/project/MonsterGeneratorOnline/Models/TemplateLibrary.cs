﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MonsterGeneratorOnline.Models
{
   public class TemplateLibrary
   {
      private static List<Template> OriginalTemplates;

      public static List<Template> GetTemplates
      {
         get
         {
            if (OriginalTemplates == null)
            {
               OriginalTemplates = new List<Template>();
               ConstructOriginalTemplates();
            }


            return OriginalTemplates;
         }
      }

      private static List<Statistic>[] templateStat = new List<Statistic>[]
      {
         new List<Statistic>()
         {
            new Statistic{
               ModifiedStatistic = "Strenght",
               Value = 4 },
            new Statistic{
               ModifiedStatistic = "Dexterity",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Constitution",
               Value = 4 },
            new Statistic{
               ModifiedStatistic = "Intelligence",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Charisma",
               Value = 4 },
            new Statistic{
               ModifiedStatistic = "Level Adjustment",
               Value = 4 },
            new Statistic{
               ModifiedStatistic = "Hit Dice",
               Value = 5 },
            new Statistic{
               ModifiedStatistic = "Armor Class",
               Value = 1 },
            new Statistic{
               ModifiedStatistic = "Wisdom",
               Value = 4 }
         },
         new List<Statistic>()
         {
            new Statistic{
               ModifiedStatistic = "Strenght",
               Value = 4 },
            new Statistic{
               ModifiedStatistic = "Dexterity",
               Value = 4 },
            new Statistic{
               ModifiedStatistic = "Constitution",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Intelligence",
               Value = 4 },
            new Statistic{
               ModifiedStatistic = "Charisma",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Level Adjustment",
               Value = 4 },
            new Statistic{
               ModifiedStatistic = "Hit Dice",
               Value = 5 },
            new Statistic{
               ModifiedStatistic = "Armor Class",
               Value = 1 }
         },
         new List<Statistic>()
         {
            new Statistic{
               ModifiedStatistic = "Strenght",
               Value = 4 },
            new Statistic{
               ModifiedStatistic = "Dexterity",
               Value = 4 },
            new Statistic{
               ModifiedStatistic = "Constitution",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Intelligence",
               Value = 4 },
            new Statistic{
               ModifiedStatistic = "Charisma",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Level Adjustment",
               Value = 4 },
            new Statistic{
               ModifiedStatistic = "Hit Dice",
               Value = 5 },
            new Statistic{
               ModifiedStatistic = "Armor Class",
               Value = 1 }
         },
         new List<Statistic>()
         {
            new Statistic{
               ModifiedStatistic = "Dexterity",
               Value = 4 },
            new Statistic{
               ModifiedStatistic = "Intelligence",
               Value = -4 },
            new Statistic{
               ModifiedStatistic = "Hit Dice",
               Value = 1 }
         },
         new List<Statistic>()
         {
            new Statistic{
               ModifiedStatistic = "Strenght",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Constitution",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Charisma",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Level Adjustment",
               Value = 1 },
            new Statistic{
               ModifiedStatistic = "Hit Dice",
               Value = 1 }
         },
         new List<Statistic>()
         {
            new Statistic{
               ModifiedStatistic = "Strenght",
               Value = -2 },
            new Statistic{
               ModifiedStatistic = "Dexterity",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Constitution",
               Value = -2 },
            new Statistic{
               ModifiedStatistic = "Charisma",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Level Adjustment",
               Value = 5 },
            new Statistic{
               ModifiedStatistic = "HitDice",
               Value = 1 }
         },
         new List<Statistic>()
         {
            new Statistic{
               ModifiedStatistic = "Strenght",
               Value = 4 },
            new Statistic{
               ModifiedStatistic = "Dexterity",
               Value = -2 },
            new Statistic{
               ModifiedStatistic = "Constitution",
               Value = -2 },
            new Statistic{
               ModifiedStatistic = "Intelligence",
               Value = -2 },
            new Statistic{
               ModifiedStatistic = "Charisma",
               Value = -4 },
            new Statistic{
               ModifiedStatistic = "Level Adjustment",
               Value = 1 }
         },
         new List<Statistic>()
         {
            new Statistic{
               ModifiedStatistic = "Hit Dice",
               Value = 6 },
            new Statistic{
               ModifiedStatistic = "Level Adjustment",
               Value = 5 }
         },
         new List<Statistic>()
         {
            new Statistic{
               ModifiedStatistic = "Hit Dice",
               Value = 6 },
            new Statistic{
               ModifiedStatistic = "Level Adjustment",
               Value = 5 }
         },
         new List<Statistic>()
         {
            new Statistic{
               ModifiedStatistic = "Hit Dice",
               Value = 5 },
            new Statistic{
               ModifiedStatistic = "Constitution",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Intelligence",
               Value = 3 },
            new Statistic{
               ModifiedStatistic = "Charisma",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Level Adjustment",
               Value = 2 }
         },
         new List<Statistic>()
         {
            new Statistic{
               ModifiedStatistic = "Hit Dice",
               Value = 6 },
            new Statistic{
               ModifiedStatistic = "Intelligence",
               Value = 3 }
         },
         new List<Statistic>()
         {
            new Statistic{
               ModifiedStatistic = "Hit Dice",
               Value = 8 },
            new Statistic{
               ModifiedStatistic = "Wisdom",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Intelligence",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Level Adjustment",
               Value = 2 }
         },
         new List<Statistic>()
         {
            new Statistic{
               ModifiedStatistic = "HitDice",
               Value = 8 },
            new Statistic{
               ModifiedStatistic = "Strenght",
               Value = 5 },
            new Statistic{
               ModifiedStatistic = "Dexterity",
               Value = 5 },
            new Statistic{
               ModifiedStatistic = "Constitution",
               Value = 5 },
            new Statistic{
               ModifiedStatistic = "Base Attack",
               Value = 8 }
         },
         new List<Statistic>()
         {
            new Statistic{
               ModifiedStatistic = "Hit Dice",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Strenght",
               Value = 4 },
            new Statistic{
               ModifiedStatistic = "Dexterity",
               Value = 8 },
            new Statistic{
               ModifiedStatistic = "Constitution",
               Value = 4 },
            new Statistic{
               ModifiedStatistic = "Wisdom",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Charisma",
               Value = 4 },
            new Statistic{
               ModifiedStatistic = "Base Attack",
               Value = 8 }
         },
         new List<Statistic>()
         {
            new Statistic{
               ModifiedStatistic = "Hit Dice",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Strenght",
               Value = 4 },
            new Statistic{
               ModifiedStatistic = "Dexterity",
               Value = -2 },
            new Statistic{
               ModifiedStatistic = "Constitution",
               Value = 8 },
            new Statistic{
               ModifiedStatistic = "Intellignces",
               Value = -2 },
            new Statistic{
               ModifiedStatistic = "Wisdom",
               Value = -4 },
            new Statistic{
               ModifiedStatistic = "Charisma",
               Value = -2 },
            new Statistic{
               ModifiedStatistic = "Level adjustment",
               Value = 5 }
         },
         new List<Statistic>()
         {
            new Statistic{
               ModifiedStatistic = "Hit Dice",
               Value = 1 },
            new Statistic{
               ModifiedStatistic = "Constitution",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Level adjustment",
               Value = 3 }
         },
         new List<Statistic>()
         {
            new Statistic{
               ModifiedStatistic = "Hit Dice",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Strenght",
               Value = 4 },
            new Statistic{
               ModifiedStatistic = "Dexterity",
               Value = -4 },
            new Statistic{
               ModifiedStatistic = "Constitution",
               Value = 4 },
            new Statistic{
               ModifiedStatistic = "Level adjustment",
               Value = 2 }
         },
         new List<Statistic>()
         {
            new Statistic{
               ModifiedStatistic = "HitDice",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Charisma",
               Value = 1 },
            new Statistic{
               ModifiedStatistic = "Dexterity",
               Value = -2 },
            new Statistic{
               ModifiedStatistic = "Wisdom",
               Value = 10 }
         },
         new List<Statistic>()
         {
            new Statistic{
               ModifiedStatistic = "Hit Dice",
               Value = 3 },
            new Statistic{
               ModifiedStatistic = "Charisma",
               Value = 1 },
            new Statistic{
               ModifiedStatistic = "Dexterity",
               Value = 2 },
            new Statistic{
               ModifiedStatistic = "Wisdom",
               Value = 10 }
         }
      };

      private static List<Ability>[] templateAbilities = new List<Ability>[]
      {
         new List<Ability>()
         {
            new Ability
            {
               AbilityName = "Darkvision",
               Level = 15
            },
            new Ability
            {
               AbilityName = "Smite evil",
               Level = 10
            }
         },
         new List<Ability>()
         {
            new Ability
            {
               AbilityName = "Darkvision",
               Level = 15
            },
            new Ability
            {
               AbilityName = "Poison immune",
               Level = 20
            },
            new Ability
            {
               AbilityName = "Smite good",
               Level = 10
            }
         },
         new List<Ability>()
         {
            new Ability
            {
               AbilityName = "Darkvision",
               Level = 15
            },
            new Ability
            {
               AbilityName = "Poison immune",
               Level = 20
            },
            new Ability
            {
               AbilityName = "Smite good",
               Level = 10
            }
         },
         new List<Ability>()
         {
            new Ability
            {
               AbilityName = "Hide",
               Level = 4
            },
            new Ability
            {
               AbilityName = "Jump",
               Level = 6
            },
            new Ability
            {
               AbilityName = "Strong mind",
               Level = 10
            }
         },
         new List<Ability>()
         {
            new Ability
            {
               AbilityName = "Low-light vision",
               Level = 12
            },
            new Ability
            {
               AbilityName = "Darkvision",
               Level = 15
            },
            new Ability
            {
               AbilityName = "Resist sleep",
               Level = 4
            },
            new Ability
            {
               AbilityName = "Resist paralysis",
               Level = 4
            }
         },
         new List<Ability>()
         {
            new Ability
            {
               AbilityName = "Darkvision",
               Level = 15
            },
            new Ability
            {
               AbilityName = "Fly",
               Level = 12
            },
            new Ability
            {
               AbilityName = "Drain resistance",
               Level = 15
            },
            new Ability
            {
               AbilityName = "Move silent",
               Level = 4
            },
            new Ability
            {
               AbilityName = "Status resistant",
               Level = 2
            }
         },
         new List<Ability>()
         {
            new Ability
            {
               AbilityName = "Darkvision",
               Level = 15
            },
            new Ability
            {
               AbilityName = "Intimidate",
               Level = 4
            },
            new Ability
            {
               AbilityName = "Drain resistance",
               Level = 15
            },
            new Ability
            {
               AbilityName = "Status resistant",
               Level = 4
            }
         },
         new List<Ability>()
         {
            new Ability
            {
               AbilityName = "Elemental",
               Level = 1
            },
            new Ability
            {
               AbilityName = "Darkvision",
               Level = 15
            }
         },
         new List<Ability>()
         {
            new Ability
            {
               AbilityName = "Elemental",
               Level = 1
            },
            new Ability
            {
               AbilityName = "Darkvision",
               Level = 15
            }
         },
         new List<Ability>()
         {
            new Ability
            {
               AbilityName = "Outsider",
               Level = 1
            },
            new Ability
            {
               AbilityName = "Turn resistance",
               Level = 4
            }
         },
         new List<Ability>()
         {
            new Ability
            {
               AbilityName = "Outsider",
               Level = 1
            }
         },
         new List<Ability>()
         {
            new Ability
            {
               AbilityName = "Shapechanger",
               Level = 1
            },
            new Ability
            {
               AbilityName = "Animal communication",
               Level = 1
            },
            new Ability
            {
               AbilityName = "Iron will",
               Level = 1
            }
         },
         new List<Ability>()
         {
            new Ability
            {
               AbilityName = "Fey",
               Level = 1
            },
            new Ability
            {
               AbilityName = "Cold damage reduction",
               Level = 5
            },
            new Ability
            {
               AbilityName = "Fly",
               Level = 1
            },
            new Ability
            {
               AbilityName = "Hide",
               Level = 8
            },
            new Ability
            {
               AbilityName = "Move silently",
               Level = 8
            },
            new Ability
            {
               AbilityName = "Survival",
               Level = 8
            }
         },
         new List<Ability>()
         {
            new Ability
            {
               AbilityName = "Magical beast",
               Level = 1
            },
            new Ability
            {
               AbilityName = "Monstrous humanoid",
               Level = 1
            },
            new Ability
            {
               AbilityName = "Magic blood",
               Level = 1
            }
         },
         new List<Ability>()
         {
            new Ability
            {
               AbilityName = "Poisonous bite",
               Level = 1
            }
         },
         new List<Ability>()
         {
         },
         new List<Ability>()
         {
         },
         new List<Ability>()
         {
            new Ability
            {
               AbilityName = "Combat reflexes",
               Level = 1
            },
            new Ability
            {
               AbilityName = "Damage reduction",
               Level = 1
            },
            new Ability
            {
               AbilityName = "Cold resistance",
               Level = 15
            }
         },
         new List<Ability>()
         {
            new Ability
            {
               AbilityName = "Improved initiative",
               Level = 1
            },
            new Ability
            {
               AbilityName = "Damage reduction",
               Level = 1
            },
            new Ability
            {
               AbilityName = "Cold resistance",
               Level = 15
            }
         }
      };

      private static string[] templateNames = new string[]
      {
         "Half-celestial", "Half-fiend", "Lemorian", "Arachnoid", "Draconic", "Fetch", "Gheden", "Wood element creature", "Fire element creature",
         "Radiant creature", "Pseudonatural", "Lycanthrope (common)", "Lycanthrope (hybrid)", "Wendigo", "Corrupted", "Poisonous", "Stoneboned",
         "Revived fossil", "Skeleton"
      };

      private static string[] restrictions = new string[]
      {
         "living, corporeal, non-evil", "living, corporeal, non-good", "living, corporeal, non-good", "animal, magical beast",
         "living, corporeal", "giant, humanoid, monstrous humanoid", "giant, humanoid, monstrous humanoid", "corporeal, aberration, animal, magical beast, plant, vermin",
         "corporeal, aberration, animal, magical beast, plant, vermin", "Aberration, Animal, Dragon, Fey, Giant, Humanoid, Magical Beast, Monstrous Humanoid",
         "corporeal", "none", "none", "Animal, Giant, Humanoid, Magical Beast, Monstrous Humanoid", "corporeal, living", "corporeal, living",
         "corporeal, living", "corporeal, non-undead", "corporeal, non-undead"
      };

      private static string[] descriptions = new string[]
      {
         "Look pleasant, often with golden skin, metallic hair, and often feathered wings",
         "Look hideous, often with dark scales, horns, and often bat wings.",
         "Look hideous, often with dark scales, horns, a scorpionlike stinger, and often bat wings.",
         "Physically weak looking person with pale, bluish, or ashen skin, sad eyes, and a melodious voice.",
         "Have some minor Dragon-like features, such as claws & tough skin",
         "Physically weak looking person with pale, bluish, or ashen skin, sad eyes, and a melodious voice",
         "Gray, corpse-like skin, with hollow, black eyes. Often gaunt, but sometimes very muscular. Smell like recently dug dirt.",
         "Appear similar to their originals, but made from wood, branches, and leaves.",
         "Appear similar to their base creatures, but bathed in flame or charred",
         "Appear similar to the original, but bright & colorful, and surrounded with rainbows, sparkling lights, etc.",
         "Looks & acts like the normal creature that is poses as, until it transforms into a mass of tentacles.",
         "Acquired or Inherited Template that is applied a Humanoid or Giant (base creature) and an Animal (base animal).",
         "Acquired or Inherited Template that is applied a Humanoid or Giant (base creature) and an Animal (base animal).",
         "Looks feral & wildeyed, with sharp teeth, matted hair, and bloody stumps instead of feet.",
         "Twisted, cancerous, & insane versions of the base creature.",
         "Creature gains large fangs that drip poison.",
         "Creature has its skeleton enlarged, with jagged bonespurs jutting through the skin.",
         "Petrified bones of the base creature.",
         "Bones of the base creature."
      };

      private static void ConstructOriginalTemplates()
      {
         Random rnd = new Random();
         for (int i = 0; i < templateNames.Length; i++)
         {
            Template t1 = new Template();
            t1.Name = templateNames[i];
            t1.Source = "D&D Template index V3.5";
            t1.Description = descriptions[i];
            t1.Rating = rnd.Next(80, 100);
            t1.RestrictedTypes = restrictions[i];
            t1.Abilities = templateAbilities[i];
            t1.Statistic = templateStat[i];

            OriginalTemplates.Add(t1);
         }
      }

      public static List<Template> Filter(string filter)
      {
         List<Template> filteredTemplates = new List<Template>();

         filteredTemplates = OriginalTemplates.FindAll(x => x.Name.ToLower().Contains(filter.ToLower()));

         return filteredTemplates;
      }

      public static List<Template> OrderBy(TemplatesSearchOptions searchOption)
      {
         List<Template> orderedTemplates = new List<Template>();

         switch (searchOption)
         {
            case TemplatesSearchOptions.OrderBy:
               orderedTemplates = OriginalTemplates;
               break;
            case TemplatesSearchOptions.Name:
               orderedTemplates = OriginalTemplates.OrderBy(x => x.Name).ToList();
               break;
            case TemplatesSearchOptions.Restriction:
               orderedTemplates = OriginalTemplates.OrderBy(x => x.RestrictedTypes).ToList();
               break;
            default:
               break;
         }

         return orderedTemplates;
      }

      public static List<Template> OrderBy(TemplatesCommunitySearchOptions searchOption)
      {
         List<Template> orderedTemplates = new List<Template>();

         switch (searchOption)
         {
            case TemplatesCommunitySearchOptions.OrderBy:
               orderedTemplates = OriginalTemplates;
               break;
            case TemplatesCommunitySearchOptions.Name:
               orderedTemplates = OriginalTemplates.OrderBy(x => x.Name).ToList();
               break;
            case TemplatesCommunitySearchOptions.Restriction:
               orderedTemplates = OriginalTemplates.OrderBy(x => x.RestrictedTypes).ToList();
               break;
            case TemplatesCommunitySearchOptions.Rating:
               orderedTemplates = OriginalTemplates.OrderByDescending(x => x.Rating).ToList();
               break;
            default:
               break;
         }

         return orderedTemplates;
      }
   }
}