﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MonsterGeneratorOnline.Models
{
   public class RestrictedScenarioLibrary
   {
      private static List<RestrictedScenario> OriginalScenarios;

      public static List<RestrictedScenario> GetScenarios
      {
         get
         {
            if (OriginalScenarios == null)
            {
               OriginalScenarios = new List<RestrictedScenario>();
               ConstructScenarios();
            }

            return OriginalScenarios;
         }
      }


      private static string[] ScenariosName = new string[]
      {
         "Tower",
         "Cathedral",
         "Bridge",
         "Castle",
         "Prison",
         "Sewer",
         "Forest",
         "Swap",
         "Desert",
         "Underworld",
         "Heaven",
         "Hill"
      };

      private static void ConstructScenarios()
      {
         for (int i = 0; i < ScenariosName.Length; i++)
         {
            RestrictedScenario r = new RestrictedScenario();
            r.Scenario = ScenariosName[i];
            r.Source = "D&D Scenario Manual V3.5";

            OriginalScenarios.Add(r);
         }
      }
   }
}