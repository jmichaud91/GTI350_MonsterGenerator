﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MonsterGeneratorOnline.Models
{
   public class Monsters
   {
      public string Name { get; set; }
      public string Description { get; set; }
      public string Abilities { get; set; }
      public string Source { get; set; }
      public MonsterTypeRestriction Type { get; set; }
      public string Str { get; set; }
      public string Dex { get; set; }
      public string Int { get; set; }
      public string Const { get; set; }
      public string Cha { get; set; }
      public string CR { get; set; }
      public string Level { get; set; }
   }
}