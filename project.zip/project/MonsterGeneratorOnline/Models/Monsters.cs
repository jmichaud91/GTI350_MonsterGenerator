﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MonsterGeneratorOnline.Models
{
   public class Monsters
   {
      public string Name { get; set; }
      public string Description { get; set; }
      public string Source { get; set; }
      public string Type { get; set; }
      public double Rating { get; set; }
      public string Scenario { get; set; }

      public string SpecialAttacks { get; set; }
      private string m_Abilities;

      public string Abilities
      {
         get
         {
            string retStat = m_Abilities;
            if (m_AppliedTemplate != null)
            {
               foreach (var stat in m_AppliedTemplate.Abilities)
               {
                  retStat += string.Format(", {0} {1}", stat.AbilityName, stat.Level);
               }
            }

            return retStat;
         }
         set { m_Abilities = value; }
      }


      private int m_Initiative;
      private int m_Hitdice;
      private int m_Speed;
      private int m_ArmorClass;
      private int m_Grapple;
      private int m_BaseAttack;
      private int m_Attack;
      private int m_FullAttack;
      private int m_Reach;
      private int m_Space;
      private int m_LevelAdjustment;
      private int m_Fortitude;
      private int m_Reflexe;
      private int m_Will;
      private int m_Wis;
      private int m_Cha;
      private int m_Const;
      private int m_Int;
      private int m_Dex;
      private int m_Str;


      public int Str
      {
         get
         {
            int retStat = m_Str;
            if (m_AppliedTemplate != null)
            {
               foreach (var stat in m_AppliedTemplate.Statistic)
               {
                  if (stat.ModifiedStatistic.ToLower() == "Strength".ToLower())
                  {
                     retStat += stat.Value;
                  }
               }
            }

            return retStat;
         }
         set { m_Str = value; }
      }


      public int Dex
      {
         get
         {
            int retStat = m_Dex;
            if (m_AppliedTemplate != null)
            {
               foreach (var stat in m_AppliedTemplate.Statistic)
               {
                  if (stat.ModifiedStatistic.ToLower() == "Dexterity".ToLower())
                  {
                     retStat += stat.Value;
                  }
               }
            }

            return retStat;
         }
         set { m_Dex = value; }
      }


      public int Int
      {
         get
         {
            int retStat = m_Int;
            if (m_AppliedTemplate != null)
            {
               foreach (var stat in m_AppliedTemplate.Statistic)
               {
                  if (stat.ModifiedStatistic.ToLower() == "Intelligence".ToLower())
                  {
                     retStat += stat.Value;
                  }
               }
            }

            return retStat;
         }
         set { m_Int = value; }
      }


      public int Const
      {
         get
         {
            int retStat = m_Const;
            if (m_AppliedTemplate != null)
            {
               foreach (var stat in m_AppliedTemplate.Statistic)
               {
                  if (stat.ModifiedStatistic.ToLower() == "Constitution".ToLower())
                  {
                     retStat += stat.Value;
                  }
               }
            }

            return retStat;
         }
         set { m_Const = value; }
      }


      public int Cha
      {
         get
         {
            int retStat = m_Cha;
            if (m_AppliedTemplate != null)
            {
               foreach (var stat in m_AppliedTemplate.Statistic)
               {
                  if (stat.ModifiedStatistic.ToLower() == "Charisma".ToLower())
                  {
                     retStat += stat.Value;
                  }
               }
            }

            return retStat;
         }
         set { m_Cha = value; }
      }


      public int Wis
      {
         get
         {
            int retStat = m_Wis;
            if (m_AppliedTemplate != null)
            {
               foreach (var stat in m_AppliedTemplate.Statistic)
               {
                  if (stat.ModifiedStatistic.ToLower() == "Wisdom".ToLower())
                  {
                     retStat += stat.Value;
                  }
               }
            }

            return retStat;
         }
         set { m_Wis = value; }
      }


      public int Will
      {
         get
         {
            int retStat = m_Will;
            if (m_AppliedTemplate != null)
            {
               foreach (var stat in m_AppliedTemplate.Statistic)
               {
                  if (stat.ModifiedStatistic.ToLower() == "Will".ToLower())
                  {
                     retStat += stat.Value;
                  }
               }
            }

            return retStat;
         }
         set { m_Will = value; }
      }


      public int Reflexe
      {
         get
         {
            int retStat = m_Reflexe;
            if (m_AppliedTemplate != null)
            {
               foreach (var stat in m_AppliedTemplate.Statistic)
               {
                  if (stat.ModifiedStatistic.ToLower() == "Reflexe".ToLower())
                  {
                     retStat += stat.Value;
                  }
               }
            }

            return retStat;
         }
         set { m_Reflexe = value; }
      }


      public int Fortitude
      {
         get
         {
            int retStat = m_Fortitude;
            if (m_AppliedTemplate != null)
            {
               foreach (var stat in m_AppliedTemplate.Statistic)
               {
                  if (stat.ModifiedStatistic.ToLower() == "Fortitude".ToLower())
                  {
                     retStat += stat.Value;
                  }
               }
            }

            return retStat;
         }
         set { m_Fortitude = value; }
      }


      public int LevelAdjustment
      {
         get
         {
            int retStat = m_LevelAdjustment;
            if (m_AppliedTemplate != null)
            {
               foreach (var stat in m_AppliedTemplate.Statistic)
               {
                  if (stat.ModifiedStatistic.ToLower() == "Level adjustment".ToLower())
                  {
                     retStat += stat.Value;
                  }
               }
            }

            return retStat;
         }
         set { m_LevelAdjustment = value; }
      }


      public int Space
      {
         get
         {
            int retStat = m_Space;
            if (m_AppliedTemplate != null)
            {
               foreach (var stat in m_AppliedTemplate.Statistic)
               {
                  if (stat.ModifiedStatistic.ToLower() == "Space".ToLower())
                  {
                     retStat += stat.Value;
                  }
               }
            }

            return retStat;
         }
         set { m_Space = value; }
      }


      public int Reach
      {
         get
         {
            int retStat = m_Reach;
            if (m_AppliedTemplate != null)
            {
               foreach (var stat in m_AppliedTemplate.Statistic)
               {
                  if (stat.ModifiedStatistic.ToLower() == "Reach".ToLower())
                  {
                     retStat += stat.Value;
                  }
               }
            }

            return retStat;
         }
         set { m_Reach = value; }
      }


      public int FullAttack
      {
         get
         {
            int retStat = m_FullAttack;
            if (m_AppliedTemplate != null)
            {
               foreach (var stat in m_AppliedTemplate.Statistic)
               {
                  if (stat.ModifiedStatistic.ToLower() == "Full Attack".ToLower())
                  {
                     retStat += stat.Value;
                  }
               }
            }

            return retStat;
         }
         set { m_FullAttack = value; }
      }


      public int Attack
      {
         get
         {
            int retStat = m_Attack;
            if (m_AppliedTemplate != null)
            {
               foreach (var stat in m_AppliedTemplate.Statistic)
               {
                  if (stat.ModifiedStatistic.ToLower() == "Attack".ToLower())
                  {
                     retStat += stat.Value;
                  }
               }
            }

            return retStat;
         }
         set { m_Attack = value; }
      }


      public int BaseAttack
      {
         get
         {
            int retStat = m_BaseAttack;
            if (m_AppliedTemplate != null)
            {
               foreach (var stat in m_AppliedTemplate.Statistic)
               {
                  if (stat.ModifiedStatistic.ToLower() == "Base Attack".ToLower())
                  {
                     retStat += stat.Value;
                  }
               }
            }

            return retStat;
         }
         set { m_BaseAttack = value; }
      }


      public int Grapple
      {
         get
         {
            int retStat = m_Grapple;
            if (m_AppliedTemplate != null)
            {
               foreach (var stat in m_AppliedTemplate.Statistic)
               {
                  if (stat.ModifiedStatistic.ToLower() == "Grapple".ToLower())
                  {
                     retStat += stat.Value;
                  }
               }
            }

            return retStat;
         }
         set { m_Grapple = value; }
      }


      public int ArmorClass
      {
         get
         {
            int retStat = m_ArmorClass;
            if (m_AppliedTemplate != null)
            {
               foreach (var stat in m_AppliedTemplate.Statistic)
               {
                  if (stat.ModifiedStatistic.ToLower() == "Armor Class".ToLower())
                  {
                     retStat += stat.Value;
                  }
               }
            }

            return retStat;
         }
         set { m_ArmorClass = value; }
      }


      public int Speed
      {
         get
         {
            int retStat = m_Speed;
            if (m_AppliedTemplate != null)
            {
               foreach (var stat in m_AppliedTemplate.Statistic)
               {
                  if (stat.ModifiedStatistic.ToLower() == "Speed".ToLower())
                  {
                     retStat += stat.Value;
                  }
               }
            }

            return retStat;
         }
         set { m_Speed = value; }
      }


      public int Hitdice
      {
         get
         {
            int retStat = m_Hitdice;
            if (m_AppliedTemplate != null)
            {
               foreach (var stat in m_AppliedTemplate.Statistic)
               {
                  if (stat.ModifiedStatistic.ToLower() == "Hit Dice".ToLower())
                  {
                     retStat += stat.Value;
                  }
               }
            }

            return retStat;
         }
         set { m_Hitdice = value; }
      }

      public int Initiative
      {
         get
         {
            int retStat = m_Initiative;
            if (m_AppliedTemplate != null)
            {
               foreach (var stat in m_AppliedTemplate.Statistic)
               {
                  if (stat.ModifiedStatistic.ToLower() == "Initiative".ToLower())
                  {
                     retStat += stat.Value;
                  }
               }
            }

            return retStat;
         }
         set { m_Initiative = value; }
      }


      private Template m_AppliedTemplate = null;

      public Template AppliedTemplate
      {
         get { return m_AppliedTemplate; }
         set { m_AppliedTemplate = value; }
      }

   }
}