﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MonsterGeneratorOnline.Models
{
   public class Abilities
   {
      public static string[] AbilitiesName = { "Darkvision", "Low-light vision", "Regeneration", "Scent", "Alertness", "Iron will", "Track" };
   }
}