﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MonsterGeneratorOnline.Controls
{
   public partial class AbilityControl : System.Web.UI.UserControl
   {
      public string Name = string.Empty;
      public string Level = string.Empty;

      protected void Page_Load(object sender, EventArgs e)
      {
         if (!Page.IsPostBack)
         {
            DLL_AbilityName.DataSource = MonsterGeneratorOnline.Models.Abilities.AbilitiesName;
            DLL_AbilityName.DataBind();

            if (Name != string.Empty && Level != string.Empty)
            {
               TextBox_Level.Text = Level;

               if (DLL_AbilityName.Items.FindByText(Name) == null)
               {
                  DLL_AbilityName.Items.Add(new ListItem(Name));
               }

               DLL_AbilityName.SelectedValue = Name;
            }
         }
      }
   }
}