﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MonsterGeneratorOnline.Controls
{
   public partial class AbilityControl : System.Web.UI.UserControl
   {
      protected void Page_Load(object sender, EventArgs e)
      {
         DLL_AbilityName.DataSource = MonsterGeneratorOnline.Models.Abilities.AbilitiesName;
         DLL_AbilityName.DataBind();
      }
   }
}