﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MonsterGeneratorOnline.Controls
{
   public partial class StatisticControl : System.Web.UI.UserControl
   {
      protected void Page_Load(object sender, EventArgs e)
      {
         DDL_Dice.DataSource = Models.Dices.DiceFaces;
         DDL_Dice.DataBind();

         DDL_StatName.DataSource = Enum.GetNames(typeof(Models.Statistics.StatNames));
         DDL_StatName.DataBind();
      }
   }
}