﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MonsterGeneratorOnline.Controls
{
   public partial class StatisticControl : System.Web.UI.UserControl
   {
      public string value = string.Empty;
      public string name = string.Empty;

      protected void Page_Load(object sender, EventArgs e)
      {
         if (!Page.IsPostBack)
         {
            DDL_Dice.DataSource = Models.Dices.DiceFaces;
            DDL_Dice.DataBind();

            DDL_StatName.DataSource = Models.Statistics.StatNames;
            DDL_StatName.DataBind();

            if (value != string.Empty && name != string.Empty)
            {
               FillInfo(name, value);
            }
         }
      }

      public void FillInfo(string name, string value)
      {
         DDL_Dice.SelectedIndex = 0;
         DDL_StatName.SelectedValue = name;
         TextBox_Dices.Text = "0";
         Textbox_Flat.Text = value;
      }
   }
}